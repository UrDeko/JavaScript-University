let pattern = /с[а-я]{2,}/ig
let str = "Силен ми е Симеон. Носи сам на рамо слон,а на слона - сто оси Симеоне, силен си!"
console.log(str.match(pattern))