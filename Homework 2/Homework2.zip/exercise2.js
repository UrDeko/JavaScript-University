let marks = [2, 4, 4, 6, 6, 4, 5, 3, 3, 2]
let filteredMarks = marks.filter(e => e >= 3 && e <= 4).length
console.log(filteredMarks)