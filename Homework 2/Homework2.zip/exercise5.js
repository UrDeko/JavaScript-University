let names = ["Стефка", "Георги", "Петър", "Васко", "Кирчо", "Анна", "Матей", "Борис-Михаил"]

let namesToUpper = names.map(e => e.toUpperCase())
console.log(namesToUpper)