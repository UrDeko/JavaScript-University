let names = ["Стефка", "Георги", "Петър", "Васко", "Кирчо", "Анна", "Матей", "Борис-Михаил"]

let filteredNames = names.filter(e => e.endsWith("а"))
console.log(filteredNames)